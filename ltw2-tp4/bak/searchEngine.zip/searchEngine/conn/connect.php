<?php
  $host = "localhost";
  $user = "root";
  $pass = "ic2a";
  $db = "searchEngine";
  $conn = mysqli_connect($host,$user,$pass,$db);
  if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
  }
?>