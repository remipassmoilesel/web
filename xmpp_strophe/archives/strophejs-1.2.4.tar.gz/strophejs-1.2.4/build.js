({
    baseUrl: ".",
    name: "bower_components/almond/almond.js",
    out: "strophe.js",
    include: ['main'],
    mainConfigFile: 'main.js'
})
